#ifndef MONSTER_H
#define MONSTER_H

#include "entity.h"
#include "config.h"
#include <vector>
#include <QPixmap>

class Monster : public Entity
{
public:
    bool dire;                      //方向
    bool cantouch;                  //怪物目前是否具有碰撞伤害
    bool isappear;                  //怪物目前是否出现
    bool isdie;                     //是否已经死亡
    bool cansteppedon;              //怪物是否能踩
    bool iskilleddirectly;          //是否直接被击杀
    std::vector<QPixmap> pixes;     //动画图片
public:
    Monster(char **, int &map_x, int x1=0, int y1=0);
    ~Monster();
    virtual void emerge()=0;            //出现
    virtual void loadpixes()=0;         //载入图片
    virtual void move();                //移动坐标
    virtual void die();                 //死亡
    virtual void beSteppedOn(bool direction)=0;      //被玩家踩踏
    virtual void beBulletAttacked(bool direction)=0; //被子弹攻击
    virtual void beKilled(bool direction)=0;         //被直接击杀
    virtual void touchEvent(bool direction);         //可以触碰时的效果
    bool canTouch();                    //获取怪物目前是否有接触伤害
    bool isDie();                       //返回怪物目前是否死亡
    bool isAppear();                    //返回怪物是否已经出现
    bool canSteppedOn();                //怪物是否能踩
protected:
    void timerEvent(QTimerEvent *)=0;
};

inline bool Monster::isDie(){return isdie;}
inline bool Monster::isAppear(){return isappear;}
inline bool Monster::canSteppedOn(){return cansteppedon;}
inline bool Monster::canTouch(){return cantouch;}

#endif // MONSTER_H
