#include "music.h"

Music::Music(QObject *parent) : QObject(parent)
{
    music_coin=new QMediaPlayer(this);
    music_coin->setMedia(QUrl(COIN_BGM));
    music_coin->setVolume(50);

    music_main = new QMediaPlayer();
    music_main->setMedia(QUrl(GROUND_BGM));
    music_main->setVolume(50);

    music_collideUpBrick=new QMediaPlayer(this);
    music_collideUpBrick->setMedia(QUrl(collideUpBrick_BGM));
    music_collideUpBrick->setVolume(50);

    music_eatmushroom=new QMediaPlayer(this);
    music_eatmushroom->setMedia(QUrl(EATMUSHROOM_BGM));
    music_eatmushroom->setVolume(50);

    music_life=new QMediaPlayer(this);
    music_life->setMedia(QUrl(LIFE_BGM));
    music_life->setVolume(50);

    music_jump=new QMediaPlayer(this);
    music_jump->setMedia(QUrl(JUMP_BGM));
    music_jump->setVolume(70);

    music_shot=new QMediaPlayer(this);
    music_shot->setMedia(QUrl(SHOT_BGM));

    music_die=new QMediaPlayer(this);
    music_die->setMedia(QUrl(DIE_BGM));

    music_killmonster=new QMediaPlayer(this);
    music_killmonster->setMedia(QUrl(KILLMONSTER_BGM));

    music_gameover=new QMediaPlayer(this);
    music_gameover->setMedia(QUrl(GAMEOVER_BGM));

    music_smallcollideUpBrick=new QMediaPlayer(this);
    music_smallcollideUpBrick->setMedia(QUrl(SMALLcollideUpBrick_BGM));
    music_smallcollideUpBrick->setVolume(100);

    music_bullet_kill=new QMediaPlayer(this);
    music_bullet_kill->setMedia(QUrl(BULLET_KILL_BGM));

    music_flower_appear=new QMediaPlayer(this);
    music_flower_appear->setMedia(QUrl(FLOWER_APPEAR_BGM));

    music_flag=new QMediaPlayer(this);
    music_flag->setMedia(QUrl(FLAG_BGM));

    music_castle=new QMediaPlayer(this);
    music_castle->setMedia(QUrl(CASTLE_BGM));

    music_small=new QMediaPlayer(this);
    music_small->setMedia(QUrl(SMALL_BGM));
}
