#include "monsters.h"

using namespace std;

Monster_Mushroom::Monster_Mushroom(char **p, int &map_x, int x1, int y1)
    :Monster(p,map_x,x1,y1)
{
    type=ENTITY_MONSTER_MUSHROOM;
    vx=-2,vy=0;
    height=width=WIDTH;
    loadpixes();
}
Monster_Mushroom::~Monster_Mushroom()
{

}
void Monster_Mushroom::loadpixes()
{
    pixes.push_back(QPixmap(MONSTER_1_WALK1));
    pixes.push_back(QPixmap(MONSTER_1_WALK2));
    pixes.push_back(QPixmap(MONSTER_1_DIE));
    pixes.push_back(QPixmap::fromImage(QPixmap(MONSTER_1_WALK1).toImage().mirrored(false,true)));
}
void Monster_Mushroom::emerge()
{
    pix=&pixes[pixindex];
    startTimer(30);
    isappear=true;
}
void Monster_Mushroom::beSteppedOn(bool)
{
    drawFrequency=0;
    isdie=true;
    cantouch=true;
    pix=&pixes[2];
}
void Monster_Mushroom::beBulletAttacked(bool direction)
{
    beKilled(direction);
}
void Monster_Mushroom::beKilled(bool direction)
{
    drawFrequency=0;
    iskilleddirectly=true;
    isdie=true;
    vx=direction?10:-10;
    vy=-10;
    ay=G;
    pix=&pixes[3];
}
void Monster_Mushroom::timerEvent(QTimerEvent *)
{
    if (!isdie)
    {
        drawFrequency=(drawFrequency+1)%4;
        if (drawFrequency==0)
        {
            pixindex=(pixindex+1)%2;
            pix=&pixes[pixindex];
        }
    }
    else if (iskilleddirectly)
    {
        if (y<WIDTH*14)
        {
            x+=vx,y+=vy;
            vy+=ay;
        }
        else die();
    }
    else
    {
        drawFrequency++;
        if (drawFrequency>=30) die();   //死亡动画
    }
}
//Monster_Tortoise/////////////////////////////////////////////////////////
Monster_Tortoise::Monster_Tortoise(char **q, int &map_x, int x1, int y1)
    :Monster(q,map_x,x1,y1)
{
    status=0;
    loadpixes();
    height=width=WIDTH;
    vx=-2,vy=0;
    type=ENTITY_MONSTER_TORTOISE;
}
Monster_Tortoise::~Monster_Tortoise()
{

}
void Monster_Tortoise::loadpixes()
{
    pixes.push_back(QPixmap::fromImage(QPixmap(MONSTER_2_WALK1).toImage().mirrored(true,false)));
    pixes.push_back(QPixmap::fromImage(QPixmap(MONSTER_2_WALK2).toImage().mirrored(true,false)));
    pixes.push_back(QPixmap(MONSTER_2_WALK1));
    pixes.push_back(QPixmap(MONSTER_2_WALK2));
    pixes.push_back(QPixmap(MONSTER_2_SHELL));
    pixes.push_back(QPixmap::fromImage(QPixmap(MONSTER_2_SHELL).toImage().mirrored(false,true)));
}
void Monster_Tortoise::beSteppedOn(bool direction)
{
    drawFrequency=0;
    if (status==0||status==2)
    {
        status=1;
        vx=0;
        pix=&pixes[4];
        cantouch=true;
    }
    else if (status==1)
    {
        status=2;
        vx=direction?10:-10;
        cantouch=false;
    }
}
void Monster_Tortoise::touchEvent(bool direction)
{
    status=2;
    vx=direction?10:-10;
    moveCoordinate();
    cantouch=false;
}
void Monster_Tortoise::beBulletAttacked(bool direction)
{
    beKilled(direction);
}
void Monster_Tortoise::beKilled(bool direction)
{
    drawFrequency=0;
    iskilleddirectly=true;
    isdie=true;
    vx=direction?10:-10;
    vy=-10;
    ay=G;
    pix=&pixes[5];
}
void Monster_Tortoise::emerge()
{
    pix=&pixes[pixindex];
    startTimer(30);
    isappear=true;
}
void Monster_Tortoise::timerEvent(QTimerEvent *)
{
    if (!isdie)
    {
        if (status>0)
        {
            if (status==1)
            {
                drawFrequency++;
                if (drawFrequency>=100)
                {
                    status=0;
                    drawFrequency=0;
                    vx=dire?2:-2;
                    cantouch=false;
                }
            }
        }
        else
        {
            drawFrequency=(drawFrequency+1)%4;
            if (drawFrequency==0)
            {
                pixindex=(pixindex+1)%2;
                pix=&pixes[pixindex+2*dire];
            }
        }
    }
    else if (iskilleddirectly)
    {
        if (y<WIDTH*14)
        {
            x+=vx,y+=vy;
            vy+=ay;
        }
        else die();
    }
}
