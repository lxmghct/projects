#include "monster.h"
#include <QPainter>
#include <QDebug>

Monster::Monster(char **p, int &map_x, int x1, int y1)
    : Entity(p,map_x,x1,y1)
{
    dire=0;
    cantouch=false;
    isappear=false;
    isdie=false;
    cansteppedon=true;
    iskilleddirectly=false;
}
Monster::~Monster()
{

}
void Monster::move()
{
    if (isdie) return;
    moveCoordinate();
    if (isLanded()) vy=0,ay=0;
    else ay=G,y+=1;
    if (isCollideWall()) vx=-vx,dire=1-dire;
}
void Monster::touchEvent(bool)
{

}
void Monster::die()
{
    isdisappear=true;
}
