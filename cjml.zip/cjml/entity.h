#ifndef ENTITY_H
#define ENTITY_H

#include <QObject>
#include <QPixmap>
#include "config.h"

class Entity : public QObject
{
public:
    int x,y;                            //坐标
    int vx,vy;                          //速度
    int ax,ay;                          //加速度
    int pixindex;                       //动图图片下标
    int type;                           //实体种类
    int height,width;                   //图片的宽和高
    int &map_point_x;                   //地图的x坐标
    char **gameArray;                   //地图二维数组
    QPixmap *pix;                       //目前图片
    QPixmap PIX_INIT;                   //初始图片
    bool isdisappear;                   //是否已经消失
    long long drawFrequency;            //画图频率
public:
    Entity(char **, int &map_x, int x1=0, int y1=0, int vx1=0, int vy1=0);
    ~Entity();
    virtual void loadpixes()=0;         //载入地图
    virtual void move();                //移动
    void moveCoordinate();              //移动坐标
    QRect rectArea();                   //获取当前坐标下的该实体矩形区域
    void draw(QPainter *);              //画出图片
    
    void disappear();                   //消失
    int collideObject_vertically();     //竖直方向是否撞到物体,若撞到则返回为物体id
    int collideObject_horizontally();   //水平方向是否撞到物体,若撞到则返回为物体id
    bool isLanded();                    //是否着陆
    bool isCollideWall();               //是否撞墙
    bool iscollideEntity(Entity *);     //是否碰到其他实体
    bool iscollideEntity_verticallly(Entity *);     //是否水平方向碰撞其他实体
    bool iscollideEntity_horizonally(Entity *);     //是否竖直方向碰撞其他实体
    //内联函数
    int pos_x() const;                  //获取x坐标
    int pos_y() const;                  //获取y坐标
    bool isDisappear() const;           //是否已经消失
    int getType() const;                //返回实体种类
protected:
    void timerEvent(QTimerEvent *)=0;
};

inline int Entity::pos_x() const {return x;}
inline int Entity::pos_y() const {return y;}
inline bool Entity::isDisappear() const {return isdisappear;}
inline int Entity::getType() const {return type;}
#endif // ENTITY_H
