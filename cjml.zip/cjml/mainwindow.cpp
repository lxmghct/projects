#include "mainwindow.h"
#include <QPainter>
#include <QPixmap>
#include <ctime>
#include <QKeyEvent>
#include <QDebug>
#include <cmath>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    //初始化场景信息
    setWindowTitle("超级玛丽");
    setFixedSize(WINDOW_WIDTH,WINDOW_HEIGHT);
    QPixmap pix(WINDOWICON);
    setWindowIcon(pix);
    drawFrequency=0;

    //初始化按键信息
    isPressUp=false;
    isPressDown=false;
    isPressLeft=false;
    isPressRight=false;
    isPressAttack=false;
    isPressJump=false;
    isPause=false;
    flagDown=false;
    isWin=false;

    //初始化
    gameArray=MapArray.gameArray;
    gamearray_row=MapArray.row;
    gamearray_col=MapArray.col;
    map1=new Map(gameArray,gamearray_row,gamearray_col);//初始化地图
    mario1=new Mario(gameArray, map1->x(),score,life,coinNum);//初始化马里奥
    player = new Music();

    //关卡及角色信息
    level=1;
    timeleft=400;
    coinNum=0;
    life=3;
    score=0;
    gamestatus=0;

    //开始游戏
    startgame();

    //启用定时器
    startTimer(20); //控制移动

    //创建怪物对象
    monsters.push_back(new Monster_Mushroom(gameArray,map1->x(),1000,3*WIDTH));
    monsters.push_back(new Monster_Mushroom(gameArray,map1->x(),1370,3*WIDTH));
    monsters.push_back(new Monster_Mushroom(gameArray,map1->x(),1400,3*WIDTH));
    //monsters.push_back(new Monster_Mushroom(gameArray,map1->x(),2000,3*WIDTH));
    monsters.push_back(new Monster_Mushroom(gameArray,map1->x(),2530,3*WIDTH));
    monsters.push_back(new Monster_Mushroom(gameArray,map1->x(),2590,3*WIDTH));
    monsters.push_back(new Monster_Mushroom(gameArray,map1->x(),3200,3*WIDTH));
    monsters.push_back(new Monster_Mushroom(gameArray,map1->x(),3260,3*WIDTH));
    monsters.push_back(new Monster_Mushroom(gameArray,map1->x(),3730,12*WIDTH));
    monsters.push_back(new Monster_Mushroom(gameArray,map1->x(),3760,12*WIDTH));
    monsters.push_back(new Monster_Mushroom(gameArray,map1->x(),5240,3*WIDTH));
    monsters.push_back(new Monster_Mushroom(gameArray,map1->x(),5370,3*WIDTH));


    monsters.push_back(new Monster_Tortoise(gameArray,map1->x(),1200,3*WIDTH));
    monsters.push_back(new Monster_Tortoise(gameArray,map1->x(),1630,3*WIDTH));
    monsters.push_back(new Monster_Tortoise(gameArray,map1->x(),3400,3*WIDTH));
    monsters.push_back(new Monster_Tortoise(gameArray,map1->x(),3460,3*WIDTH));
    monsters.push_back(new Monster_Tortoise(gameArray,map1->x(),5080,3*WIDTH));
}

MainWindow::~MainWindow()
{
    delete mario1;
    delete map1;
}
void MainWindow::startgame()
{
    if (mario1->isDie()) life--;                  //死亡则生命减一，否则进入下一关
    if (life==0)
    {
        player->music_gameover->play();
        gamestatus=-150;   //生命减至零则结束
    }
    else gamestatus=100;
    timeleft=400;
    if (mario1->pos_x()>2564) mario1->initialize(2564,12*WIDTH);
    else mario1->initialize(100,11*WIDTH);
    map1->setmapx(0);
}
void MainWindow::drawinformation(QPainter *painter)
{
    //画右侧的操作说明
    painter->drawPixmap(WINDOW_WIDTH-INSTRUCTION_WIDTH,0,INSTRUCTION_WIDTH,WINDOW_HEIGHT,QPixmap(INSTRUCTION));
    //将顶部信息栏分成四个部分，分别是分数栏、金币栏、关卡栏、时间栏，间隔为inteval
    int x0=WIDTH, y0=WIDTH;
    int inteval=(WINDOW_WIDTH-INSTRUCTION_WIDTH)/4;
    //设置画笔文字样式
    QFont font;
    font.setPointSize(15);
    painter->setPen(QPen(QBrush(Qt::white),4));
    painter->setFont(font);
    //分数栏
    painter->drawText(x0,y0,"马  利");
    QString str;
    if (score==0) str+="00000";
    else for (int i=0;i<5-(int)log10(score);i++) str+="0";
    str+=QString().sprintf("%d",score);
    painter->drawText(x0,y0+WIDTH,str);
    //金币栏
    static QPixmap coinpixes[3]={QPixmap(COIN_PIX1),QPixmap(COIN_PIX2),QPixmap(COIN_PIX3)};
    QPixmap *coin1;
    if (drawFrequency<5) coin1=&coinpixes[1];
    else if (drawFrequency>=5&&drawFrequency<10) coin1=&coinpixes[2];
    else coin1=&coinpixes[0];
    painter->drawPixmap(x0+inteval,y0+WIDTH/4,WIDTH,WIDTH,*coin1);
    QString().swap(str);
    str+="  X ";
    if (coinNum<10) str+="0";
    str+=QString().sprintf("%d",coinNum);
    painter->drawText(x0+inteval,y0+WIDTH,str);
    //关卡栏
    painter->drawText(x0+inteval*2,y0,"关  卡");
    QString().swap(str);
    str.sprintf("%d - %d",(level-1)/4+1,(level-1)%4+1);
    painter->drawText(x0+2*inteval,y0+WIDTH,str);
    //时间栏
    painter->drawText(x0+inteval*3,y0,"时  间");
    if (gamestatus==0)
    {
        QString().swap(str);
        str.sprintf("%d",timeleft);
        painter->drawText(x0+3*inteval,y0+WIDTH,str);
    }
}
void MainWindow::paintEvent(QPaintEvent *)
{
    QPainter painter(this);             //创建画家
    map1->drawbackground(&painter);      //画背景
    for (int i=0;i<(int)entities.size();i++) entities[i]->draw(&painter);   //画其他实体
    map1->drawObstacles(&painter);       //画障碍物
    //画所有实体
    mario1->draw(&painter);
    for (int i=0;i<(int)monsters.size();i++) monsters[i]->draw(&painter);
    for (int i=0;i<(int)bullets.size();i++) bullets[i]->draw(&painter);
    //画开始背景
    if (gamestatus!=0)
    {
        QFont font;
        font.setPointSize(15);
        painter.setPen(QPen(QBrush(Qt::white),4));
        painter.setFont(font);
        int x0=(WINDOW_WIDTH-INSTRUCTION_WIDTH)/2-WIDTH;
        int y0=WINDOW_HEIGHT/2;
        painter.drawPixmap(0,0,WINDOW_WIDTH,WINDOW_HEIGHT,QPixmap(STARTBK_PIX));
        if (gamestatus>0)
        {
            painter.drawPixmap(x0-WIDTH/2,y0-WIDTH/2,WIDTH,WIDTH,QPixmap(MARI1_PIX));
            painter.drawText(x0,y0+WIDTH/3,QString().sprintf("   X %d",life));
        }
        else painter.drawText(x0-WIDTH,y0+WIDTH/3,"游 戏 结 束");
    }
    //画说明
    drawinformation(&painter);

}
void MainWindow::keyPressEvent(QKeyEvent *event)
{
    if (gamestatus!=0) return;
    if (mario1->isPause()) return;
    if (isPause==true&&event->key()!=Qt::Key_P) return;  //暂停时禁用除暂停键以外的任何按键
    switch (event->key())
    {
    case Qt::Key_W:isPressUp=true; break;
    case Qt::Key_S:isPressDown=true; break;
    case Qt::Key_A:isPressLeft=true; break;
    case Qt::Key_D:isPressRight=true;break;
    case Qt::Key_J:isPressAttack=true;
        if (mario1->canAttack()&&!mario1->isSquat()&&Bullet::bulletNum()<2)
        {
            player->music_shot->setPosition(0);
            player->music_shot->play();
            Bullet *a=new Bullet(gameArray,map1->x(),mario1->pos_x()+WIDTH/2,mario1->pos_y()+WIDTH/2,mario1->getDirection());
            bullets.push_back(a);
            mario1->shot();
        }
        break;
    case Qt::Key_K:if (mario1->isJump()) break;
        isPressJump=true;player->music_jump->setPosition(0);
        player->music_jump->play();
        presstime=clock();
        mario1->jump();
        break;
    case Qt::Key_P:isPause=isPause==false?true:false; break;
    }
    update();
}
void MainWindow::keyReleaseEvent(QKeyEvent *event)
{
    switch (event->key())
    {
    case Qt::Key_W:isPressUp=false; break;
    case Qt::Key_S:isPressDown=false; break;
    case Qt::Key_A:isPressLeft=false;  break;
    case Qt::Key_D:isPressRight=false; break;
    case Qt::Key_J:isPressAttack=false; break;
    case Qt::Key_K:isPressJump=false; break;
    }
    update();
}
void MainWindow::timerEvent(QTimerEvent *)
{
    if (player->music_main->position()==88920) player->music_main->play();
//PART0:基本游戏设置
    update();
    drawFrequency=(drawFrequency+1)%30;     //drawFrequency用于控制画金币闪动的频率
    if (gamestatus!=0)                      //游戏未开始
    {
        gamestatus+=gamestatus>0?-1:1;
        if(gamestatus==0)
        {
            player->music_main->play();
        }
        return;        
    }
    if (mario1->isDie()&&player->music_die->position()<900){
        player->music_main->stop();
        player->music_die->setPosition(900);
        player->music_die->play();
    }
    if (mario1->isPause()) return;          //场面出现吃蘑菇、变小等静止事件则暂停
    if (mario1->isDie())
    {
        startgame();
        player->music_die->stop();
        player->music_die->setPosition(0);
        return;
    }
    if (timeleft==0)
    {
        mario1->die();
        return;
    }
    if (drawFrequency%15==0&&timeleft>0) timeleft--;
//PART1:按键控制
    if (isPressUp)
    {

    }
    if (isPressDown)
    {
        if (mario1->isBig())
        {
            mario1->squat();   //蹲下
        }
    }
    else if (mario1->isSquat()) mario1->standup();
    if (isPressJump)
    {
        if ((clock()-presstime)/(double)CLOCKS_PER_SEC>=0.25||mario1->getvy()>0)
        {
            isPressJump=false;
        }
        else mario1->jump();
    }
    if (isPressLeft||isPressRight)
    {
        if (isPressDown) mario1->standup();
        else
        {
            if (isPressLeft) mario1->setdirection(-1);  //朝左
            if (isPressRight) mario1->setdirection(1);  //朝右
            if (isPressAttack) mario1->speedUp(true); //按住攻击键时切换为疾跑状态
            else mario1->speedUp(false);
        }
    }
    else
    {
        mario1->setdirection(0);
    }
//PART2:移动地图和马里奥
    //若马里奥处于一定位置的右侧，则移动地图坐标
    mario1->move();
    int D=(WINDOW_WIDTH-INSTRUCTION_WIDTH)/3;
    if (mario1->pos_x()-map1->x()>D&&map1->x()<gamearray_col*WIDTH-WINDOW_WIDTH)//避免马里奥超过终点
    {
        map1->backgroundPosition(mario1->pos_x()-map1->x()-D);
    }
//PART3:马里奥与怪物相碰
    if (!mario1->isGetHurt())
    {
        for (int i=0;i<(int)monsters.size();i++)
        {
            Monster *mon=monsters[i];
            if (mon->isDie()) continue;                 //碰撞到怪物尸体则碰撞无效
            if (!mario1->iscollideEntity(mon)) continue;    //未接触则不做判断
            if (mario1->getvy()>0&&mario1->iscollideEntity_verticallly(mon))    //踩怪物
            {
                mario1->jump();
                mario1->moveCoordinate();
                player->music_killmonster->play();
                mon->beSteppedOn(mario1->pos_x()<mon->pos_x());
            }
            else if (mon->canTouch()) mon->touchEvent(mario1->getDirection());  //水平方向碰撞
            else mario1->getAttacked();
        }
    }
//PART4:马里奥与其他实体相碰
    for (int i=0;i<(int)entities.size();i++)
    {
        Entity *e=entities[i];
        if (!mario1->iscollideEntity(e)) continue;
        e->disappear();
        switch (e->getType())
        {
        case ENTITY_MUSHROOM_1:     //蘑菇1
            mario1->eatMushroom();
            break;
        case ENTITY_MUSHROOM_2:     //蘑菇2
            life++;
           player->music_life->play();
            break;
        case ENTITY_FLOWER:         //花
            mario1->eatFlower();
            break;
        }
    }
//PART5:子弹与怪物相碰
    for (int i=0;i<(int)bullets.size();i++)
    {
        Bullet *b=bullets[i];
        for (int j=0;j<(int)monsters.size();j++)
        {
            Monster *m=monsters[j];
            if (!m->isAppear()) continue;
            if (b->iscollideEntity(m)&&b->isharmful)
            {
                m->beBulletAttacked(m->pos_x()>b->pos_x());
                player->music_bullet_kill->play();
                b->boom();
            }
        }
    }
//PART6:怪物与怪物相碰
    for (int i=0;i<(int)monsters.size();i++)
    {
        Monster *mon1=monsters[i];
        for (int j=i+1;j<(int)monsters.size();j++)
        {
            Monster *mon2=monsters[j];
            if (mon1->isDie()||mon2->isDie()) continue;
            if (mon1->iscollideEntity(mon2))
            {
                if (mon1->getType()==ENTITY_MONSTER_TORTOISE&&((Monster_Tortoise *)mon1)->status==2)
                {
                    mon2->beKilled(mon2->pos_x()>mon1->pos_x());
                }
                else if (mon2->getType()==ENTITY_MONSTER_TORTOISE&&((Monster_Tortoise *)mon2)->status==2)
                {
                    mon1->beKilled(mon1->pos_x()>mon2->pos_x());
                }
                else
                {
                    mon1->vx=-mon1->vx;
                    mon2->vx=-mon2->vx;
                    mon1->dire=1-mon1->dire;
                    mon2->dire=1-mon2->dire;
                    mon1->move();
                    mon2->move();
                }
            }
        }
    }
//PART7:怪物刷新
    for (int i=0;i<(int)monsters.size();i++)
    {
        Monster *mon=monsters[i];
        if (mon->isDisappear())   //怪物死亡，则从怪物数组中移除该指针
        {
            monsters.erase(monsters.begin()+i);
            delete mon;
            continue;
        }
        else if (mon->isAppear()) mon->move();
        if (mon->pos_x()-mario1->pos_x()<=MAX_DISTANCE&&mario1->pos_x()-mon->pos_x()<=D)
        {
            if (!mon->isAppear())
            {
                mon->emerge();    //当玩家走到怪物附近则生成怪物
            }
        }
        else
        {
            if (mon->isAppear()) mon->die();        //当玩家走到怪物一定范围之外则删除该怪物
        }
        if (!mon->isDie())          //若怪物脚下的砖被顶，则怪物死亡
        {
            if (mon->pos_y()>=14) continue;
            int tt=gameArray[mon->pos_y()/WIDTH+1][mon->pos_x()/WIDTH];
            if ((tt>40||tt==-1)&&!mon->isDie()&&!mon->isDisappear()) mon->beKilled(mario1->getDirection());
        }
    }
//PART8:子弹刷新
    for (int i=0;i<(int)bullets.size();i++)
    {
        Bullet *a=bullets[i];
        if (a->isDisappear()||a->pos_x()-mario1->pos_x()>MAX_DISTANCE||mario1->pos_x()-a->pos_x()>D)
        {
            bullets.erase(bullets.begin()+i);
            delete a;
        }
        else a->move();
    }
//PART9:刷新其他实体
    for (int i=0;i<(int)entities.size();i++)    //移除消失的和超过一定范围的实体指针
    {
        Entity *e=entities[i];
        if (e->isDisappear()||e->pos_x()-mario1->pos_x()>MAX_DISTANCE||mario1->pos_x()-e->pos_x()>D)
        {
            entities.erase(entities.begin()+i);
            delete e;
        }
        else e->move();
    }
//若含有特殊物品的砖块被顶，则生成相应实体
    for(int i=0;i<gamearray_row;i++)
    {
        for(int j=0;j<gamearray_col;j++)
        {
            switch (gameArray[i][j])
            {
            case BLANK_BRICK_1:
                player->music_flower_appear->play();
                if (!mario1->isBig()) entities.push_back(new Mushroom1(gameArray,map1->x(),j*WIDTH,(i-1)*WIDTH));
                else entities.push_back(new Flower(gameArray,map1->x(),j*WIDTH,(i-1)*WIDTH));
                gameArray[i][j]=BLANK_BRICK;
                break;
            case BLANK_BRICK_2:
                player->music_flower_appear->play();
                entities.push_back(new Mushroom2(gameArray,map1->x(),j*WIDTH,(i-1)*WIDTH));
                gameArray[i][j]=BLANK_BRICK;
                break;
            case BLANK_BRICK_3:
                player->music_coin->setPosition(0);
                player->music_coin->play();
                entities.push_back(new JumpCoin(gameArray,map1->x(),j*WIDTH,(i-1)*WIDTH));
                score+=200;
                coinNum++;
                gameArray[i][j]=BLANK_BRICK;
                break;
            default:
                break;
            }
        }
    }

    //PART10:胜利动画
    if(mario1->x>=200.5*WIDTH&&!flagDown)
    {
        isPause=true;
        if(map1->flag_y<10.5*WIDTH)
        {
           mario1->x=200.5*WIDTH;
           map1->flag_y+=FLAG_SPEED;
           player->music_flag->play();
        }
        else
        {
            flagDown=true;
        }
    }
    if(flagDown&&!isWin)
    {
        player->music_main->stop();
        player->music_castle->play();
        if(mario1->x<209*WIDTH)isPressRight=true;
        else
        {
            mario1->x=220*WIDTH;
            isPressRight=false;
            isWin=true;
        }

    }
    if (flagDown&&timeleft>1) timeleft--;
}
