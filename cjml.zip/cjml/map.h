#ifndef MAP_H
#define MAP_H

#include <QPixmap>
#include <QObject>
#include <vector>
#include "config.h"

class JumpBrick;
class BrickFragment;
class Map : public QObject
{
public:
    int background_posX;                //地图X轴坐标
    int flag_y;                         //旗子y坐标
    char **gameArray;                   //障碍物数组
    int gamearray_row,gamearray_col;    //数组行数和列数
    int pixindex;                       //动态障碍物图片下标
    int hit_i,hit_j;                    //被马里奥顶中的方块坐标
    QPixmap background;                 //背景图片
    JumpBrick *jumpbrick;               //被顶起弹跳的方块
    BrickFragment *brickfragment;       //方块碎片
    //障碍物对象
    QPixmap brick;
    QPixmap pipe;
    QPixmap ground;
    QPixmap stone;
    QPixmap flagpole;
    QPixmap flag;
    QPixmap ball;
    QPixmap castle;
    QPixmap blankbrick;
    QPixmap *coin;
    QPixmap *randbrick;   
    //动态障碍物数组
    std::vector<QPixmap> coins;
    std::vector<QPixmap> randbricks;
public:
    Map(char **, int rows, int cols);
    ~Map();
    void drawbackground(QPainter *);                //画背景
    void drawObstacles(QPainter *);                 //画障碍物
    void backgroundPosition(int m_scroll_speed);    //地图滚动坐标
    void setmapx(int);                              //设置地图当前的横坐标
    //void FlagMove();                                //旗子下降动画
    int &x();                                       //获取x坐标，返回为background_posx的引用
protected:
    void timerEvent(QTimerEvent *);
};
inline int &Map::x() {return background_posX;}

class JumpBrick : public QObject
{
    int &_i,&_j;                //弹起方块的下标，声明为引用类型是为了方便向地图数组传递结束弹跳的信号
    int &map_point_x;           //地图横坐标
    int x,y;                    //弹起方块的坐标
    QPixmap *pix;               //弹起方块的图片
    int vy;                     //vy
    int y0;                     //未弹起时的纵坐标，用于作为弹跳结束的控制条件
    bool isStart;               //是否开始弹跳
public:
    JumpBrick(int &map_x, int &i, int &j);
    ~JumpBrick();
    void start(QPixmap *);      //开始弹跳
    void draw(QPainter *);
    bool isstart();
protected:
    void timerEvent(QTimerEvent *);
};

class BrickFragment : public QObject
{
    QPixmap pix;                //方块碎片图片
    int &map_point_x;           //地图横坐标
    static int x[4],y[4];       //方块碎片有四块，分别朝着四个方向飞出，用数组存储其坐标和速度
    static int vx[4],vy[4];
    bool isStart;               //方块破碎动画开始
public:
    BrickFragment(int &map_x);
    ~BrickFragment();
    void start(int x1, int y1);
    void draw(QPainter *);
    bool isstart();
protected:
    void timerEvent(QTimerEvent *);
};

#endif // MAP_H
