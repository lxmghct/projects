#include "entity.h"
#include <QPainter>
#include <QDebug>

Entity::Entity(char **p, int &map_x, int x1, int y1, int vx1, int vy1)
    :map_point_x(map_x)
{
    x=x1,y=y1;
    vx=vx1,vy=vy1;
    ax=ay=0;
    gameArray=p;
    type=0;
    pixindex=0;
    height=width=WIDTH-5;
    isdisappear=false;
    drawFrequency=0;
    pix=&PIX_INIT;
}
Entity::~Entity()
{

}
void Entity::draw(QPainter *paint)
{
    paint->drawPixmap(x-map_point_x,y,width,height,*pix);
}
void Entity::moveCoordinate()
{
    if (y>=20*WIDTH)
    {
        isdisappear=true;
        return;
    }
    vx+=ax;
    vy+=ay;
    if (x<0) {x=0;isdisappear=true;return;} //不允许越界
/*为防止移动坐标后与障碍物发生重叠，在不会与障碍物发生碰撞的情况下时正常移动，即x+=vx,y+=vy;
 * 而在会发生重叠时，则从当前位置令x或y每次只移动一个单位长度，直至与障碍物碰撞
 * 以下分别从x方向和y方向完成上述过程*/
    if (collideObject_horizontally()<=COIN) x+=vx;
    else
    {
        x-=vx;
        int t=vx>0?1:-1;
        while(collideObject_horizontally()<=COIN) x+=t;
        x+=vx-t;
    }
    if (collideObject_vertically()<=COIN) y+=vy;
    else
    {
        y-=vy;
        int t=vy>0?1:-1;
        while(collideObject_vertically()<=COIN) y+=t;
        y+=vy-t;
    }
    //qDebug()<<x<<" "<<y<<" "<<vy<<" "<<ay;
}
void Entity::move()
{
    moveCoordinate();

}
void Entity::disappear()
{
    isdisappear=true;
}
QRect Entity::rectArea()
{
    return QRect(x,y,width,height);
}
int Entity::collideObject_vertically()
{
    int object=0;
    y+=vy;
    QRect rect(x,y,width,height);
    int y1=vy<0?y/WIDTH*WIDTH:(y+height)/WIDTH*WIDTH;           //若向上运动，则判断上方的方块；若向下或y方向静止，则判断脚下的方块
    for (int x1=x/WIDTH*WIDTH;x1<=(x+width)/WIDTH*WIDTH;x1+=WIDTH)  //从左侧第一个方块依次判断至右侧第一个方块
    {
        if (y1<0||y1>=15*WIDTH) continue;
        int object1=gameArray[y1/WIDTH][x1/WIDTH];
        if (object1!=0&&rect.intersects(QRect(x1,y1,WIDTH,WIDTH)))
        {
            if (object1>object||object1<0) object=object1;             //返回序数最大的障碍物，从而当同时撞上金币和石头时，优先碰到金币
        }
    }
    y-=vy;
    return object;
}
int Entity::collideObject_horizontally()        //用和竖直方向碰撞同样的思路完成水平方向的碰撞
{
    int object=0;
    x+=vx;
    QRect rect(x,y,width,height);
    int x1=vx<0?x/WIDTH*WIDTH:(x+width)/WIDTH*WIDTH;
    for (int y1=y/WIDTH*WIDTH;y1<=(y+height)/WIDTH*WIDTH;y1+=WIDTH)
    {
        if (y1<0||y1>=15*WIDTH) continue;
        int object1=gameArray[y1/WIDTH][x1/WIDTH];
        if (object1!=0&&rect.intersects(QRect(x1,y1,WIDTH,WIDTH)))
        {
            if (object1>object) object=object1;
        }
    }
    x-=vx;
    return object;
}
bool Entity::isLanded()
{
    if (vy<0) return false;     //若向上运动则不进行落地检测
    //思路：先将vy置零，然后向下移动一单位长度,判断是否与方块重叠
    int t=vy;
    y++;vy=0;
    bool island=collideObject_vertically()>COIN;
    y--;vy=t;
    return island;
}
bool Entity::isCollideWall()
{
    if (collideObject_horizontally()>COIN) return true;
    else return false;
}
bool Entity::iscollideEntity(Entity *p)
{
    if (rectArea().intersects(p->rectArea())) return true;      //若两实体的矩形区域重叠，则返回true
    else return false;
}
bool Entity::iscollideEntity_horizonally(Entity *p)
{
    if (!iscollideEntity(p)) return false;      //若两实体未碰撞，则不做判断
    //以实体p为参考系，计算相对速度v_x和v_y
    int v_x=vx-p->vx;
    int v_y=vy-p->vy;
    if (v_y==0) return true;
    if (v_x==0) return false;
    //以实体p为参考系，计算碰撞前后的相对位移xx和yy
    int xx,yy;
    if (v_x>0&&v_y>0) xx=x+width-p->x,yy=y+height-p->y;
    if (v_x<0&&v_y>0) xx=p->x+p->width-x,yy=y+height-p->y;
    if (v_x>0&&v_y<0) xx=x+width-p->x,yy=p->y+p->height-y;
    if (v_x<0&&v_y<0) xx=p->x+p->width-x,yy=p->y+p->height-y;
    /*碰撞方向为水平的条件是：速度方向的倾斜角小于位移方向的倾斜角
     * 以下用余切表示这两个倾斜角*/
    if (ABS(v_x)/(double)ABS(v_y)>xx/(double)yy) return true;
    else return false;
}
bool Entity::iscollideEntity_verticallly(Entity *p)
{
    return !iscollideEntity_horizonally(p);
}
