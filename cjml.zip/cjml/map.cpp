#include "map.h"
#include <QPainter>
#include <QDebug>

Map::Map(char **p, int rows, int cols)
{
    //初始化旗子y坐标
    flag_y=4*WIDTH;
    //初始化加载地图对象
    background.load(BACKGROUND_PIX);
    background_posX=0;
    gameArray=p;
    gamearray_row=rows,gamearray_col=cols;
    pixindex=0;
    hit_i=hit_j=-1;
    jumpbrick=new JumpBrick(x(),hit_i,hit_j);
    brickfragment=new BrickFragment(x());
    //障碍物初始化
    flagpole.load(FLAG_POLE_PIX);
    flag.load(FLAG_PIX);
    ball.load(FLAG_BALL_PIX);
    castle.load(CASTLE_PIX);
    stone.load(STONE_PIX);
    brick.load(BRICK_PIX1);
    pipe.load(PIPE_PIX1);
    ground.load(GROUND_PIX);
    blankbrick.load(BLANK_BRICK_PIX);
    //动态障碍物初始化
    randbricks.push_back(QPixmap(RAND_BRICK_PIX2));
    randbricks.push_back(QPixmap(RAND_BRICK_PIX3));
    for (int i=0;i<3;i++) randbricks.push_back(QPixmap(RAND_BRICK_PIX1));
    coins.push_back(QPixmap(COIN_PIX2));
    coins.push_back(QPixmap(COIN_PIX3));
    for (int i=0;i<3;i++) coins.push_back(QPixmap(COIN_PIX1));
    coin=&coins[0];
    randbrick=&randbricks[0];
    startTimer(150);
}
Map::~Map()
{
    delete jumpbrick;
    delete brickfragment;
}
void Map::backgroundPosition(int m_scroll_speed)
{
    background_posX+=m_scroll_speed;
}
void Map::drawbackground(QPainter *paint)
{
    paint->drawPixmap(-x(),0,background);
}
void Map::setmapx(int x1)
{
    background_posX=x1;
}

void Map::drawObstacles(QPainter *painter)
{  
    painter->drawPixmap(200.1*WIDTH-x(),4*WIDTH,2.8*WIDTH,9*WIDTH,flagpole);//画旗杆
    painter->drawPixmap(201.2*WIDTH-x(),3.4*WIDTH,ball);//画球
    painter->drawPixmap(200.1*WIDTH-x(),flag_y,flag);//画旗子
    painter->drawPixmap(206.1*WIDTH-x(),3*WIDTH,castle);//画城堡

    for(int i=0;i<gamearray_row;i++)
    {
        for(int j=0;j<gamearray_col;j++)
        {
            if (i==hit_i&&j==hit_j) continue;       //如果该方块弹起，则不画出
            QPixmap *pix=nullptr;
            if (gameArray[i][j]>50)         //大于50表示该方块被撞击
            {
                gameArray[i][j]-=50;
                hit_i=i,hit_j=j;
            }
            switch(gameArray[i][j])
            {
            case BRICK_1: pix=&brick; break;        //画砖头
            case COIN: pix=coin; break;             //画金币
            case STONE: pix=&stone;break;            //画石头
            case PIPE:                              //画小水管
                if(gameArray[i-1][j]!=PIPE&&gameArray[i][j-1]!=PIPE)
                {
                    int t1=i,t2=j;
                    while (gameArray[++t1][j]==PIPE);   //计算水管宽度
                    while (gameArray[i][++t2]==PIPE);   //计算水管高度
                    painter->drawPixmap(-x()+WIDTH*j,WIDTH*i,(t2-j)*WIDTH,(t1-i)*WIDTH,pipe);
                }
                break;
            case GROUND_BRICK:
            if (gameArray[i-1][j]!=GROUND_BRICK){
                painter->drawPixmap(-x()+WIDTH*j,WIDTH*i,WIDTH,2*WIDTH,ground);     //画地板
            }
                break;
            case RAND_BRICK_1:
            case RAND_BRICK_2:
            case RAND_BRICK_3:
                pix=randbrick;                  //画问号
                break;
            case BLANK_BRICK_1:
            case BLANK_BRICK_2:
            case BLANK_BRICK_3:
            case BLANK_BRICK:
                pix=&blankbrick;                //画空白方块
                break;
            }
            if (pix!=nullptr) painter->drawPixmap(-x()+WIDTH*j,WIDTH*i,WIDTH,WIDTH,*pix);
            //以下为砖块被顶起来和砖块被撞碎的动画
            if (jumpbrick->isstart()) continue;
            else if (hit_i>=0||(gameArray[i][j]>=BLANK_BRICK_1&&gameArray[i][j]<=BLANK_BRICK_3))
            {
                hit_i=i,hit_j=j;
                jumpbrick->start(pix);
            }
            if (gameArray[i][j]==-10)
            {
                gameArray[i][j]=0;
                brickfragment->start(j*WIDTH,i*WIDTH);
            }
        }
    }
    if (jumpbrick->isstart()) jumpbrick->draw(painter);
    if (brickfragment->isstart()) brickfragment->draw(painter);


}
void Map::timerEvent(QTimerEvent *)
{
    pixindex=(pixindex+1)%5;
    coin=&coins[pixindex];
    randbrick=&randbricks[pixindex];
}

//JumpBrick////////////////////////////////////////////////
JumpBrick::JumpBrick(int &map_x, int &i, int &j)
    :map_point_x(map_x),_i(i),_j(j)
{
    x=y=0;
    vy=0;
    y0=0;
    pix=nullptr;
    isStart=false;
    startTimer(40);
}
JumpBrick::~JumpBrick()
{

}
void JumpBrick::start(QPixmap *p)
{
    pix=p;
    vy=-6;
    y0=WIDTH*_i;
    x=WIDTH*_j,y=y0-1;
    isStart=true;
}
void JumpBrick::draw(QPainter *paint)
{
    paint->drawPixmap(x-map_point_x,y,WIDTH,WIDTH,*pix);
}
void JumpBrick::timerEvent(QTimerEvent *)
{
    if (!isStart) return;
    y+=vy;
    vy+=G;
    if (y>y0)
    {
        _i=-1,_j=-1;        //将hit_i和hit_j置为-1作为结束的条件
        isStart=false;
    }
}
bool JumpBrick::isstart()
{
    return isStart;
}

//BrickFragment///////////////////////////////////////////////
int BrickFragment::x[4]={0};
int BrickFragment::y[4]={0};
int BrickFragment::vx[4]={0};
int BrickFragment::vy[4]={0};
BrickFragment::BrickFragment(int &map_x)
    :map_point_x(map_x)
{
    isStart=false;
    pix.load(BRICK_FRAGMENT);
    startTimer(30);
}
BrickFragment::~BrickFragment()
{

}
void BrickFragment::start(int x1, int y1)
{
    for (int i=0;i<4;i++)
    {
        x[i]=x1,y[i]=y1;
    }
    vx[0]=-10,vy[0]=-10;
    vx[1]=10,vy[1]=-10;
    vx[2]=-5,vy[2]=-5;
    vx[3]=5,vy[3]=-5;
    isStart=true;
}
void BrickFragment::draw(QPainter *paint)
{
    for (int i=0;i<4;i++) paint->drawPixmap(x[i]-map_point_x,y[i],WIDTH/2,WIDTH/2,pix);
}
bool BrickFragment::isstart()
{
    return isStart;
}
void BrickFragment::timerEvent(QTimerEvent *)
{
    if (!isStart) return;
    for (int i=0;i<4;i++)
    {
        x[i]+=vx[i];
        y[i]+=vy[i];
        vy[i]+=G;
        if (y[i]>18*WIDTH)
        {
            isStart=false;
            break;
        }
    }
}
