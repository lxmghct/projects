#ifndef LOADMAP_H
#define LOADMAP_H

#include <QMainWindow>
class LoadMap
{

public:
    char **gameArray;
    int row,col;//行数 列数
    LoadMap();
    ~LoadMap();
};

#endif // LOADMAP_H
