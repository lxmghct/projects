#include "bullet.h"
#include "config.h"
#include <QPainter>
#include <QDebug>

int Bullet::num=0;

Bullet::Bullet(char **p, int &map_x, int x1, int y1, bool direction)
    :Entity(p,map_x,x1,y1)
{
    type=ENTITY_BUTTEL;
    vy=15;
    vx=direction?15:-15;
    x-=3*vx,y-=3*vy;
    width=height=WIDTH*2/3;
    iscollide=false;
    isHitThing=false;
    startTimer(30);
    loadpixes();
    num++;
    isharmful=true;
}
Bullet::~Bullet()
{
    num--;
}
int Bullet::bulletNum()
{
    return num;
}
void Bullet::loadpixes()
{
    pixes.push_back(QPixmap(BULLET_PIX));
    pixes.push_back(QPixmap::fromImage(QPixmap(BULLET_PIX).toImage().mirrored(true,false)));
    pixes.push_back(QPixmap::fromImage(QPixmap(BULLET_PIX).toImage().mirrored(true,true)));
    pixes.push_back(QPixmap::fromImage(QPixmap(BULLET_PIX).toImage().mirrored(false,true)));
    pixes.push_back(QPixmap(BULLET_BOOM_PIX));      //爆炸效果
}
void Bullet::move()
{
    if (isHitThing) return;         //撞到东西后不移动
    moveCoordinate();
    if (isCollideWall())
    {
        boom();
    }
    else if (isLanded())
    {
        if (!iscollide)         //若第一次碰到地面，则改为抛物线移动
        {
            iscollide=true;
            ay=G;
        }
        vy=-10;
    }
}
void Bullet::boom()
{
    drawFrequency=0;
    isHitThing=true;
    x+=vx,y+=vy;
    height=width=WIDTH;
    pix=&pixes[4];
    isharmful=false;
}
void Bullet::timerEvent(QTimerEvent *)
{
    if (!isHitThing)
    {
        drawFrequency=(drawFrequency+1)%4;
        if (drawFrequency==0)
        {
            pixindex=(pixindex+1)%4;
            pix=&pixes[pixindex];
        }
    }
    else
    {
        if (drawFrequency>4)
        {
            disappear();
        }
        drawFrequency++;
    }
}
