#ifndef BULLET_H
#define BULLET_H

#include "entity.h"

class Bullet : public Entity
{
    std::vector<QPixmap> pixes;
    static int num;             //当前子弹数目
    bool iscollide;             //是否已经发生碰撞（子弹在第一次撞墙前是直线运动，撞墙后变为抛物线运动。
    bool isHitThing;            //是否撞到物体（怪物、墙）
public:
    bool isharmful;
    Bullet(char **, int &map_x, int x1, int y1, bool direction);
    ~Bullet();
    void loadpixes();       //载入图片
    void move();            //坐标移动
    void boom();            //撞到物体后
    static int bulletNum(); //返回当前的子弹数
protected:
    void timerEvent(QTimerEvent *);
};

#endif // BULLET_H
