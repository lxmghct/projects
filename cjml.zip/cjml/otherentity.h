#ifndef OTHERENTITY_H
#define OTHERENTITY_H

#include "entity.h"

class Mushroom1 : public Entity
{
    int yy;
    int timeId;
    bool isemerge;
public:
    Mushroom1(char **, int &map_x, int x1, int y1);
    ~Mushroom1();
    void loadpixes();
    void move();
protected:
    void timerEvent(QTimerEvent *);
};

class Mushroom2 : public Mushroom1
{
public:
    Mushroom2(char **, int &map_x, int x1, int y1);
    ~Mushroom2();
};

class Flower : public Entity
{
    int yy;
    bool isemerge;              //是否出现，用于控制花长出来的动画
    std::vector<QPixmap> pixes;
public:
    Flower(char **, int &map_x, int x1, int y1);
    ~Flower();
    void loadpixes();
    void move();
protected:
    void timerEvent(QTimerEvent *);
};

class JumpCoin : public Entity
{
    int y0;                     //硬币初始y坐标，用于作为判断硬币弹跳结束的条件
    std::vector<QPixmap> pixes;
public:
    JumpCoin(char **, int &map_x, int x1, int y1);
    ~JumpCoin();
    void loadpixes();
    void move();
protected:
    void timerEvent(QTimerEvent *);
};



#endif // OTHERENTITY_H
