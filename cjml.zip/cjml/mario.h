#ifndef MARIO_H
#define MARIO_H

#include <QPixmap>
#include <QMediaPlayer>
#include "entity.h"
#include <vector>
#include "config.h"
#include "music.h"

class Mario : public Entity
{

    int stage;           //马里奥状态，0为小，1位变大，2为能发子弹
    bool direction;       //朝向,0为左，1为右
    bool isdie;          //是否死亡
    bool isjump;         //是否在空中
    bool issquat;        //是否蹲下
    bool isSpeedUp;      //是否加速
    bool isPressMove;    //是否按下左右移动键
    bool ispause;        //是否因某些事件暂停场景
    int isShot;          //是否在发子弹
    int isgethurt;       //是否受到伤害处于短暂无敌状态
    int isEatMushroom;   //是否吃蘑菇
    int isEatFlower;     //是否吃花

    std::vector<QPixmap> pixes[3][2];   //马里奥动画图片
    QPixmap die_pix;

    int &score;          //分数
    int &coins;          //金币数
    int &life;           //生命值
public:
    Mario(char **, int &map_x, int &_sco, int &_life, int &_coin);
    void loadpixes();                   //载入马里奥动画图片
    void land();                        //落地
    void initialize(int x1, int y1);    //初始化
    void standup();                     //站起来
    void jump();                        //跳跃
    void setdirection(int);             //改变方向
    void squat();                       //蹲下
    void collideUpBrick();              //顶到方块
    void collideWall();                 //撞到墙
    void eatMushroom();                 //吃到蘑菇变大
    void eatFlower();                   //吃到花
    void eatCoin();                     //吃到金币
    void getAttacked();                 //受到攻击
    void becomeSmall();                 //碰到怪变小
    void die();                         //死亡
    void speedUp(bool);                 //加速
    void shot();                        //发子弹
    void move();                        //移动坐标
    //内联函数
    bool isSquat();                     //是否蹲下
    bool isJump();                      //是否处于空中
    bool getDirection() const;           //获取当前方向
    int getvy() const;                  //y方向速度
    bool isBig();                       //判断是否变大
    bool canAttack();                   //是否可以攻击
    bool isGetHurt();                   //是否受到伤害
    bool isPause();                     //是否因某些事件暂停场景
    bool isDie();                       //是否死亡

    Music * player1;                      //音效对象

protected:
    void timerEvent(QTimerEvent *);
};

inline int Mario::getvy() const {return vy;}
inline bool Mario::isJump() {return isjump;}
inline bool Mario::isBig() {return stage>0;}
inline bool Mario::isSquat() {return issquat;}
inline bool Mario::canAttack() {return stage==2;}
inline bool Mario::getDirection() const {return direction;}
inline bool Mario::isGetHurt() {return isgethurt;}
inline bool Mario::isPause() {return ispause;}
inline bool Mario::isDie() {return isdie;}

#endif // MARIO_H
