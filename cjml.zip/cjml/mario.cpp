#include "mario.h"
#include<QPixmap>
#include <QRect>
#include <QDebug>
#include <QPainter>
#include <ctime>

using namespace std;

Mario::Mario(char **p, int &map_x, int &_sco, int &_life, int &_coin)
    :Entity(p, map_x), life(_life), coins(_coin), score(_sco)
{
    stage=0;
    type=ENTITY_MARIO;
    height=WIDTH;
    initialize(100,60);//100
    loadpixes();
    player1 = new Music();
    startTimer(20);
}
void Mario::loadpixes()
{
    for (int i=0;i<6;i++) pixes[0][1].push_back(QPixmap(QString(":/image/mari0_%1").arg(i)));
    for (int i=0;i<6;i++) pixes[0][0].push_back(QPixmap::fromImage(QPixmap(QString(":/image/mari0_%1").arg(i)).toImage().mirrored(true,false)));
    for (int i=0;i<7;i++) pixes[1][1].push_back(QPixmap(QString(":/image/mari1_%1").arg(i)));
    for (int i=0;i<7;i++) pixes[1][0].push_back(QPixmap::fromImage(QPixmap(QString(":/image/mari1_%1").arg(i)).toImage().mirrored(true,false)));
    for (int i=0;i<8;i++) pixes[2][1].push_back(QPixmap(QString(":/image/mari2_%1").arg(i)));
    for (int i=0;i<8;i++) pixes[2][0].push_back(QPixmap::fromImage(QPixmap(QString(":/image/mari2_%1").arg(i)).toImage().mirrored(true,false)));
    die_pix.load(DIE);
}
void Mario::initialize(int x1, int y1)
{
    x=x1,y=y1;
    vx=0,vy=0;
    direction=1;
    isjump=false;
    issquat=false;
    isSpeedUp=false;
    isPressMove=false;
    isdisappear=false;
    ispause=false;
    isdie=false;
    isShot=0;
    isgethurt=0;
    isEatMushroom=0;
    isEatFlower=0;
}
void Mario::land()
{
    isjump=false;
    ay=0;
    vy=0;
}
void Mario::collideUpBrick()
{
    int object1=collideObject_vertically();
    if ((vy<0&&object1<=COIN&&object1>=0)||vy>=0) return;    //速度朝下或者顶到的物体不是砖块，则结束
    //若同时顶到两块砖，判断是顶了左侧的砖还是右侧的
    int xx=x/WIDTH,y0=y/WIDTH-1;
    int x1,x2,x0;
    if (x>xx*WIDTH+WIDTH/2) x1=xx+1,x2=xx;
    else x1=xx,x2=xx+1;
    x0=gameArray[y0][x1]>COIN?x1:x2;
    //根据顶到的砖种类，进行相应的处理
    int object=gameArray[y0][x0];
    if (object==COIN||object==0) return;
    vy=1;                               //顶砖反弹
    switch (object)
    {
    case BRICK_1:
    case BRICK_2:
        if (isBig())                //变大则顶碎
        {
            player1->music_collideUpBrick->setPosition(0);
            player1->music_collideUpBrick->play();
            gameArray[y0][x0]=-10;
            score+=50;
        }
        else
        {
            player1->music_smallcollideUpBrick->setPosition(0);
            player1->music_smallcollideUpBrick->play();
            gameArray[y0][x0]+=50; //若未变大则使砖块弹起
        }
        break;
    case RAND_BRICK_1:
        gameArray[y0][x0]=BLANK_BRICK_1+50;
        break;
    case RAND_BRICK_2:
        gameArray[y0][x0]=BLANK_BRICK_2+50;
        break;
    case RAND_BRICK_3:
        gameArray[y0][x0]=BLANK_BRICK_3+50;
        break;
    case INVISIBLE_BRICK_1:
        gameArray[y0][x0]=BLANK_BRICK_1;
        break;
    case INVISIBLE_BRICK_2:
        gameArray[y0][x0]=BLANK_BRICK_2;
        break;
    case INVISIBLE_BRICK_3:
        gameArray[y0][x0]=BLANK_BRICK_3;
        break;
    }
}
void Mario::collideWall()
{
    if (isCollideWall()) vx=0;
}
void Mario::squat()
{
    if (isBig()&&!issquat)
    {
        height=WIDTH;
        issquat=true;
        y+=WIDTH;
    }
}
void Mario::standup()
{
    if (issquat)
    {
        height=2*WIDTH;
        issquat=false;
        y-=WIDTH;
    }
}
void Mario::jump()
{
    vy=JUMP_SPEED;
    isjump=true;
}
void Mario::setdirection(int i)
{
    if (i==0) isPressMove=false;
    else isPressMove=true;
    if (isPressMove) ax=i*MARI_A;       //isPressMove时产生持续的加速度
    if (i<0) direction=0;
    else if (i>0) direction=1;
}
void Mario::eatMushroom()
{
    player1->music_eatmushroom->play();
    if (stage>0) eatFlower();
    else
    {
        height=2*WIDTH;
        stage=1;
        y-=WIDTH;
        isEatMushroom++;        //触发吃蘑菇动画
        ispause=true;
    }
}
void Mario::eatFlower()
{
    player1->music_eatmushroom->play();
    if (stage==2) return;
    else if (stage==0) eatMushroom();
    else
    {
        ispause=true;
        isEatFlower++;          //触发吃花动画
        stage=2;
    }
}
void Mario::eatCoin()
{
    QRect rect=rectArea();
    for (int i=x/WIDTH-2;i<x/WIDTH+2;i++)
    {
        if (i<0) continue;
        for (int j=y/WIDTH-1;j<(y+height)/WIDTH+1;j++)
        {
            if (j<0) continue;
            if (j>=15) continue;
            if (gameArray[j][i]==COIN&&rect.intersects(QRect(i*WIDTH,j*WIDTH,WIDTH,WIDTH)))
            {
                gameArray[j][i]=0;
                player1->music_coin->setPosition(0);
                player1->music_coin->play();
                coins++;
                if (coins>=100)
                {
                    life++,coins%=100;   //金币满100，则自动转化成1次生命加成
                   player1->music_life->play();
                }
                score+=200;
            }
        }
    }
}
void Mario::becomeSmall()
{
    stage=0;
    height=WIDTH;
    player1->music_small->play();
    isgethurt++;
    ispause=true;
}
void Mario::die()
{
    stage=0;
    height=WIDTH;
    pix=&die_pix;
    vx=0,vy=-20;
    ay=G;
    ispause=true;
    isdie=true;
    drawFrequency=0;
    isdisappear=false;
}
void Mario::getAttacked()
{
    if (!isBig()) die();
    else becomeSmall();
}
void Mario::speedUp(bool s)
{
    isSpeedUp=s;
}
void Mario::shot()
{
    isShot++;
}
void Mario::move()
{
    moveCoordinate();
    if (x<=map_point_x)     //防止从左侧跑出地图
    {
        x=map_point_x;
        if (vx<0)
        {
            vx=0;
            ax=0;
        }
    }
    if (vy>=WIDTH) vy=WIDTH-1;              //限制自由下落的速度，防止其直接穿过方块
    if (drawFrequency%2==0) vx-=ax;         //使加速度降为原先的一半
    if (isLanded())         //检测落地
    {
        if (isjump) land();
        else ay=0;
    }
    else
    {
        isjump=true;
        ay=G;
    }
    if (!isPressMove&&vx!=0)        //滑行状态
    {
        ax=vx>0?-MARI_A:MARI_A;
        if (ABS(vx)<=MARI_A)
        {
            vx=0;
            ax=0;
        }
    }
    collideUpBrick();
    collideWall();
    eatCoin();
    int maxspeed=isSpeedUp?SPEED*3/2:SPEED;     //加速时速度变为1.5倍
    if (ABS(vx)>maxspeed) vx=direction?maxspeed:-maxspeed;      //设置最大速度
}
void Mario::timerEvent(QTimerEvent *)
{
    if (isdisappear) die();
    if (isdie)
    {
        drawFrequency++;
        if (drawFrequency>10&&drawFrequency<100) y+=vy, vy+=ay;
        if (drawFrequency>100) ispause=false;
        return;
    }
    drawFrequency=(drawFrequency+1)%(4-(isSpeedUp<<1));
    if (isgethurt)
    {
        if (isgethurt<=26)
        {
            if (isgethurt%4==0) {pix=&pixes[1][direction][2];y-=WIDTH;height=2*WIDTH;}
            if (isgethurt%4==2) {pix=&pixes[0][direction][2];y+=WIDTH;height=WIDTH;}
        }
        isgethurt=(isgethurt+1)%50;
        if (isgethurt==25) ispause=false;
    }
    else if (isEatMushroom)
    {
        if (isEatMushroom%4==0) {pix=&pixes[1][direction][0];y-=WIDTH;height=2*WIDTH;}
        if (isEatMushroom%4==2) {pix=&pixes[0][direction][0];y+=WIDTH;height=WIDTH;}
        isEatMushroom=(isEatMushroom+1)%30;
        if (isEatMushroom==0) ispause=false;
    }
    else if (isEatFlower)
    {
        if (isEatFlower%4==0) pix=&pixes[2][direction][0];
        if (isEatFlower%4==2) pix=&pixes[1][direction][0];
        isEatFlower=(isEatFlower+1)%30;
        if (isEatFlower==0) ispause=false;
    }
    else if (issquat) pix=&pixes[stage][direction][6];
    else if (isShot) {pix=&pixes[2][direction][7];isShot=(isShot+1)%5;}
    else if (isjump) pix=&pixes[stage][direction][4];
    else if (vx==0) pix=&pixes[stage][direction][0];
    else if (vx*ax<0&&isPressMove) pix=&pixes[stage][1-direction][5];
    else
    {
        if (drawFrequency==0) pixindex=(pixindex+1)%3+1;
        pix=&pixes[stage][direction][pixindex];
    }
}
