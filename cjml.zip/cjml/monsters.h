#ifndef MONSTERS_H
#define MONSTERS_H

#include "monster.h"
#include <vector>

class Monster_Mushroom : public Monster
{
public:
    Monster_Mushroom(char **, int &map_x, int x1=0, int y1=0);
    ~Monster_Mushroom();
    void loadpixes();
    void beSteppedOn(bool);
    void beBulletAttacked(bool direction);
    void beKilled(bool direction);
    void emerge();
protected:
    void timerEvent(QTimerEvent *);
};

class Monster_Tortoise : public Monster
{
public:
    int status;
    Monster_Tortoise(char **, int &map_x, int x1=0, int y1=0);
    ~Monster_Tortoise();
    void loadpixes();
    void beSteppedOn(bool);
    void beBulletAttacked(bool direction);
    void beKilled(bool direction);
    void emerge();
    void touchEvent(bool direction);
protected:
    void timerEvent(QTimerEvent *);
};


#endif // MONSTERS_H
