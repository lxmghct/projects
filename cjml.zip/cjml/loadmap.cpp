#include "loadmap.h"
#include <QByteArray>
#include <QFile>
#include <QString>
#include <QFileDialog>
#include <QMessageBox>
#include <QObject>
#include <QDebug>
#include <iostream>

LoadMap::LoadMap()
{
    //计算行数和列数
    QFile file1(":/map/map1_1.txt");
    if (!file1.open(QIODevice::ReadOnly))
    {
        QMessageBox::information(NULL," ","无法打开文件");
        return;
    }
    //计算行数
    col=0;
    QString str=file1.readLine();
    for (int i=0;i<str.length();i++)
    {
        if (str[i]==','||str[i]=='\n') col++;
    }
    //计算列数
    row=1;
    while (!file1.atEnd())
    {
        file1.readLine();
        row++;
    }
    file1.close();
    //存放地图数据
    gameArray=new char*[row];
    for (int i=0;i<row;i++) gameArray[i]=new char[col];
    QFile file2(":/map/map1_1.txt");
    if (!file2.open(QIODevice::ReadOnly))
    {
        QMessageBox::information(NULL," ","无法打开文件");
        return;
    }
    for (int i=0;i<row;i++)          //按行读取存入QByteArray中，结尾有换行符
    {
        QByteArray str=file2.readLine();
        int point=0;                    //该行中的读取位置
        int temp=0;                     //用于进行字符串转化为数字
        int sign=1;                     //用于记录正负号
        for (int j=0;j<str.length();j++)
        {
            if (str[j]==' '||str[i]=='\r') continue;          //忽略空格和回车符
            if (str[j]>='0'&&str[j]<='9')
            {
                temp=temp*10+str[j]-'0';        //字符串转数字
            }
            else if (str[j]=='-')
            {
                sign=-1;
            }
            else
            {
                gameArray[i][point++]=sign*temp;     //若遇到非数字字符（逗号、换行符），则存入
                temp=0;
                sign=1;
            }
        }
    }
    file2.close();
}
LoadMap::~LoadMap()
{
    for (int i=0;i<row;i++) delete []gameArray[i];
    delete []gameArray;
}
