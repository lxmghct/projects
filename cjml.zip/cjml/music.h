#ifndef MUSIC_H
#define MUSIC_H

#include <QObject>
#include <QMediaPlayer>

#include "config.h"

class Music : public QObject
{
    Q_OBJECT
public:
    explicit Music(QObject *parent = nullptr);

    QMediaPlayer * music_main;         //主BGM
    QMediaPlayer * music_jump;         //跳音效
    QMediaPlayer * music_coin;         //金币音效对象
    QMediaPlayer * music_collideUpBrick; //顶破砖音效对象
    QMediaPlayer * music_eatmushroom; //吃花或蘑菇音效对象
    QMediaPlayer * music_life;         //加命音效对象
    QMediaPlayer * music_shot;        //发射子弹
    QMediaPlayer * music_die;          //死亡
    QMediaPlayer * music_killmonster;  //踩怪物
    QMediaPlayer * music_gameover;     //游戏结束
    QMediaPlayer * music_smallcollideUpBrick;//小马里奥撞砖音效
    QMediaPlayer * music_bullet_kill;  //火球或壳击敌人
    QMediaPlayer * music_flower_appear;//顶出蘑菇,花或星
    QMediaPlayer * music_flag;         //旗子
    QMediaPlayer * music_castle;          //城堡
    QMediaPlayer * music_small;          //缩小
signals:

public slots:
};

#endif // MUSIC_H
