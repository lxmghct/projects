#ifndef CONFIG_H
#define CONFIG_H


////////////////数据信息////////////////////////
#define WIDTH 30
#define WINDOW_WIDTH 800
#define WINDOW_HEIGHT 450
#define INSTRUCTION_WIDTH 150
#define SPEED 6
#define JUMP_SPEED -17
#define G 3
#define MARI_A 1  //马里奥x方向加速度
#define MAX_DISTANCE 600
#define FLAG_SPEED  5   //旗子下降速度

//障碍物数据
#define INVISIBLE_BRICK_1 -1        //隐形砖块(内含蘑菇/花)
#define INVISIBLE_BRICK_2 -2        //隐形砖块(内含加命蘑菇)
#define INVISIBLE_BRICK_3 -3        //隐形砖块(内含金币)
#define COIN 1                      //金币
#define BRICK_1 2                   //可顶碎的砖块1
#define BRICK_2 3                   //可顶碎的砖块2
#define PIPE 4                      //水管
#define STONE 6                     //石头
#define GROUND_BRICK 5              //地板砖
#define RAND_BRICK_1 31             //问号方块(内含蘑菇/花)
#define RAND_BRICK_2 32             //问号方块(内含加命的蘑菇)
#define RAND_BRICK_3 33             //问号方块(内含金币)
#define BLANK_BRICK 40              //顶完问号后的空白方块
#define BLANK_BRICK_1 41            //顶完问号后的空白方块(内含蘑菇/花)
#define BLANK_BRICK_2 42            //顶完问号后的空白方块(内含加命的蘑菇)
#define BLANK_BRICK_3 43            //顶完问号后的空白方块(内含金币)
//#define FLAG
//#define FLAG_POLE
//#define FLAG_BALL
//#define CASTLE

//实体种类
#define ENTITY_MARIO 1                  //马里奥
#define ENTITY_MUSHROOM_1 2             //蘑菇1
#define ENTITY_MUSHROOM_2 3             //蘑菇2
#define ENTITY_FLOWER 4                 //花
#define ENTITY_BUTTEL 5                 //子弹
#define ENTITY_JUMPCOIN 6               //蹦跳的金币
#define ENTITY_MONSTER_MUSHROOM 21      //蘑菇怪
#define ENTITY_MONSTER_TORTOISE 22      //乌龟怪

///////////////图片信息////////////////////////
#define DIE ":/image/die.png"                       //死亡图像
#define MARI1_PIX ":/image/mari0_0.png"             //马里奥初始图片
#define WINDOWICON ":/image/mario.png"              //窗口图标
#define INSTRUCTION ":/image/instruction.png"       //说明书
#define BACKGROUND_PIX  ":/image/startBack.jpg"     //背景
#define STARTBK_PIX ":/image/startbackground.png"   //开始界面背景(黑屏)
#define MUSHROOM1 ":/image/mushroom1.png"           //蘑菇1
#define MUSHROOM2 ":/image/mushroom2.png"           //蘑菇2
#define COIN_PIX1 ":/image/coin1.png"               //金币图片1
#define COIN_PIX2 ":/image/coin2.png"               //金币图片2
#define COIN_PIX3 ":/image/coin3.png"               //金币图片3
#define BRICK_PIX1  ":/image/brick.png"             //砖块
#define PIPE_PIX1   ":/image/pipe.png"              //水管
#define GROUND_PIX  ":/image/brick3.png"            //地板
#define STONE_PIX   ":/image/brick4.png"            //石头
#define BULLET_PIX ":/image/bullet.png"             //子弹
#define BULLET_BOOM_PIX ":/image/bulletboom.png"    //子弹爆炸效果
#define MONSTER_1_WALK1 ":/image/monster_walk1.png" //蘑菇怪（方向1）
#define MONSTER_1_WALK2 ":/image/monster_walk2.png" //蘑菇怪（方向2）
#define MONSTER_1_DIE ":/image/monster_death.png"   //蘑菇怪被压扁图片
#define RAND_BRICK_PIX1 ":/image/randbrick1.png"    //问号方块图片1
#define RAND_BRICK_PIX2 ":/image/randbrick2.png"    //问号方块图片2
#define RAND_BRICK_PIX3 ":/image/randbrick3.png"    //问号方块图片3
#define BLANK_BRICK_PIX ":/image/randbrick0.png"    //空白方块
#define BRICK_FRAGMENT ":/image/brickfragment.png"  //砖块碎片
#define MONSTER_2_WALK1 ":/image/tortoise1.png"     //乌龟怪图片1
#define MONSTER_2_WALK2 ":/image/tortoise2.png"     //乌龟怪图片2
#define MONSTER_2_SHELL ":/image/tortoise3.png"     //乌龟壳
#define FLAG_POLE_PIX  ":/image/flagpole1.png"       //旗杆
#define FLAG_BALL_PIX   ":/image/ball1.png"         //球
#define FLAG_PIX        ":/image/flag1.png"         //旗子
#define CASTLE_PIX     ":/image/castle1.png"        //城堡

///////////////音乐信息////////////////////////
#define GROUND_BGM  "qrc:/music//地上.mp3"
#define JUMP_BGM    "qrc:/music//跳.mp3"
#define COIN_BGM    "qrc:/music//金币.mp3"
#define SHOT_BGM  "qrc:/music//扔火球.mp3"
#define collideUpBrick_BGM "qrc:/music//顶破砖.mp3"
#define SMALLcollideUpBrick_BGM "qrc:/music//顶砖石块,壳击墙或火球撞墙.mp3"
#define DIE_BGM     "qrc:/music//死亡.mp3"
#define GAMEOVER_BGM    "qrc:/music//Game Over.mp3"
#define EATMUSHROOM_BGM "qrc:/music//吃到蘑菇或花.mp3"
#define LIFE_BGM    "qrc:/music//加一条命.mp3"
#define KILLMONSTER_BGM  "qrc:/music//踩敌人.mp3"
#define BULLET_KILL_BGM  "qrc:/music//火球或壳击敌人.mp3"
#define FLOWER_APPEAR_BGM   "qrc:/music//顶出蘑菇,花或星.mp3"
#define FLAG_BGM    "qrc:/music//拉旗.mp3"
#define CASTLE_BGM  "qrc:/music//进入城堡.mp3"
#define SMALL_BGM   "qrc:/music//进管或缩小.mp3"

///////////////函数///////////////////////////
#define ABS(a) ((a)<0?(-a):(a))

#endif // CONFIG_H
