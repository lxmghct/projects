#include "otherentity.h"

//Mushroom1////////////////////////////////////////////////////////////
Mushroom1::Mushroom1(char **p, int &map_x, int x1, int y1)
    :Entity(p,map_x,x1,y1)
{
    yy=y;
    y+=WIDTH;
    isemerge=false;
    type=ENTITY_MUSHROOM_1;
    loadpixes();
    timeId=startTimer(20);
}
Mushroom1::~Mushroom1()
{

}
void Mushroom1::loadpixes()
{
    PIX_INIT.load(MUSHROOM1);
}
void Mushroom1::move()
{
    if (!isemerge) return;
    moveCoordinate();
    if (isLanded()) ay=0,vy=0;
    else ay=G;
    if (isCollideWall()) vx=-vx;
}
void Mushroom1::timerEvent(QTimerEvent *)
{
    y--;
    if (yy==y)
    {
        isemerge=true;
        vx=3;
        killTimer(timeId);
    }
}

//Mushroom2////////////////////////////////////////////////////////////////
Mushroom2::Mushroom2(char **p, int &map_x, int x1, int y1)
    :Mushroom1(p,map_x,x1,y1)
{
    type=ENTITY_MUSHROOM_2;
    PIX_INIT.load(MUSHROOM2);
}
Mushroom2::~Mushroom2()
{

}

//Flower///////////////////////////////////////////////////////////////////
Flower::Flower(char **p, int &map_x, int x1, int y1)
    :Entity(p,map_x,x1,y1)
{
    yy=y;
    y+=WIDTH;
    isemerge=false;
    type=ENTITY_FLOWER;
    loadpixes();
    startTimer(20);
}
Flower::~Flower()
{

}
void Flower::loadpixes()
{
    for (int i=0;i<4;i++) pixes.push_back(QPixmap(QString(":/image/flower%1.png").arg(i+1)));
}
void Flower::timerEvent(QTimerEvent *)
{
    if (!isemerge)
    {
        y--;
        if (yy==y) isemerge=true;
    }
    drawFrequency=(drawFrequency+1)%4;
    if (drawFrequency==0)
    {
        pixindex=(pixindex+1)%4;
        pix=&pixes[pixindex];
    }
}
void Flower::move()
{

}

//JumpCoin///////////////////////////////////////////////////////////
JumpCoin::JumpCoin(char **p, int &map_x, int x1, int y1)
    :Entity(p,map_x,x1,y1,0,-20)
{
    type=ENTITY_JUMPCOIN;
    ay=G;
    y0=y;
    startTimer(10);
    loadpixes();
}
JumpCoin::~JumpCoin()
{

}
void JumpCoin::loadpixes()
{
    for (int i=0;i<4;i++) pixes.push_back(QPixmap(QString(":/image/coin_jump_%1").arg(i+1)));
}
void JumpCoin::move()
{
    y+=vy;
    vy+=ay;
}
void JumpCoin::timerEvent(QTimerEvent *)
{
    if (y>y0) disappear();
    drawFrequency=(drawFrequency+1)%4;
    if (drawFrequency==0)
    {
        pixindex=(pixindex+1)%4;
        pix=&pixes[pixindex];
    }
}
