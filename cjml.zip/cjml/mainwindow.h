#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPixmap>
#include <QPainter>
#include <QTimer>
#include <QKeyEvent>
#include <QMediaPlayer>

#include "config.h"
#include "map.h"
#include "mario.h"
#include "loadmap.h"
#include "monsters.h"
#include "bullet.h"
#include "otherentity.h"
#include "music.h"

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    Mario *mario1;      //马里奥对象指针
    Map *map1;          //地图对象指针
    //按键状态
    bool isPressUp;
    bool isPressDown;
    bool isPressRight;
    bool isPressLeft;
    bool isPressAttack;
    bool isPressJump;
    bool isPause;
    bool flagDown;
    bool isWin;
    //关卡及角色信息
    int level;          //第几关
    int life;           //剩余生命
    int timeleft;       //剩余时间
    int score;          //分数
    int coinNum;        //拾得的金币数
    int gamestatus;     //当前游戏状态，0为游戏状态，大于0为开始界面状态，小于0为死亡结束界面状态
    //地图信息
    LoadMap MapArray;   //地图数组对象
    char **gameArray;   //二维数组
    int gamearray_row,gamearray_col;        //二维数组的行数和列数

    //音效对象
    Music * player;

    long long presstime;
    int drawFrequency;
    std::vector<Monster *> monsters;    //所有怪物
    std::vector<Bullet *> bullets;      //所有子弹
    std::vector<Entity *> entities;     //存储其他实体（蘑菇、子弹、金币、花等）

    void startgame();                   //开始游戏
    void drawinformation(QPainter *);   //画游戏信息
protected:
    //重写键盘事件
    void keyPressEvent(QKeyEvent *);
    void keyReleaseEvent(QKeyEvent *);
    //time事件
    void timerEvent(QTimerEvent *);
    //重写paintEvent事件
    void paintEvent(QPaintEvent *);
};

#endif // MAINWINDOW_H
